/**
 * Main application component with routing configuration
 */
import React from 'react';
import { HashRouter, Route, Routes, Navigate } from 'react-router';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginPage from './components/LoginPage';
import DashboardLayout from './components/Layout/DashboardLayout';
import HomePage from './pages/Dashboard/HomePage';
import ProfilePage from './pages/Dashboard/ProfilePage';
import AttendanceReport from './pages/Dashboard/AttendanceReport';
import AttendanceRequest from './pages/Dashboard/AttendanceRequest';
import CoursesPage from './pages/Dashboard/CoursesPage';
import MyCourse from './pages/Dashboard/MyCourse';
import CourseFeedback from './pages/Dashboard/CourseFeedback';
import AssignmentPage from './pages/Dashboard/AssignmentPage';
import InternalMarks from './pages/Dashboard/InternalMarks';
import NoDue from './pages/Dashboard/NoDue';
import Revaluation from './pages/Dashboard/Revaluation';
import FinancialRecord from './pages/Dashboard/FinancialRecord';

/**
 * Protected route component that requires authentication
 */
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />;
};

/**
 * Main application component with routing
 */
const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <DashboardLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<HomePage />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="my-course" element={<MyCourse />} />
            <Route path="courses" element={<CoursesPage />} />
            <Route path="feedback" element={<CourseFeedback />} />
            <Route path="attendance/report" element={<AttendanceReport />} />
            <Route path="attendance/request" element={<AttendanceRequest />} />
            <Route path="assignment" element={<AssignmentPage />} />
            <Route path="examination/internal" element={<InternalMarks />} />
            <Route path="examination/no-due" element={<NoDue />} />
            <Route path="examination/revaluation" element={<Revaluation />} />
            <Route path="financial" element={<FinancialRecord />} />
          </Route>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </HashRouter>
    </AuthProvider>
  );
};

export default App;
