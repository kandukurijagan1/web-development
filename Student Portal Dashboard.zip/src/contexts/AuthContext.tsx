/**
 * Authentication context for managing user login state and session management
 */
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  dateOfBirth: string;
  address: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  login: (username: string, password: string, rememberMe: boolean) => boolean;
  logout: () => void;
  resetInactivityTimer: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const INACTIVITY_TIMEOUT = 60000; // 1 minute in milliseconds

/**
 * Authentication provider component that manages user session and auto-logout
 */
export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [inactivityTimer, setInactivityTimer] = useState<NodeJS.Timeout | null>(null);

  // Default user data
  const defaultUser: User = {
    id: '192472374',
    name: 'Kandukuri Jagan',
    email: 'kandukurijagan99@gmail.com',
    dateOfBirth: '14/06/2006',
    address: 'balijapalem village, varadaiah palem mandal, tirupati district, Andhra Pradesh'
  };

  /**
   * Login function with credential validation
   */
  const login = (username: string, password: string, rememberMe: boolean): boolean => {
    if (username === '192472374' && password === '123') {
      setIsAuthenticated(true);
      setUser(defaultUser);
      
      if (rememberMe) {
        localStorage.setItem('authData', JSON.stringify({ user: defaultUser, rememberMe: true }));
      }
      
      startInactivityTimer();
      return true;
    }
    return false;
  };

  /**
   * Logout function that clears session data
   */
  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('authData');
    if (inactivityTimer) {
      clearTimeout(inactivityTimer);
    }
  };

  /**
   * Reset inactivity timer on user activity
   */
  const resetInactivityTimer = () => {
    if (inactivityTimer) {
      clearTimeout(inactivityTimer);
    }
    if (isAuthenticated) {
      startInactivityTimer();
    }
  };

  /**
   * Start inactivity timer for auto-logout
   */
  const startInactivityTimer = () => {
    const timer = setTimeout(() => {
      logout();
    }, INACTIVITY_TIMEOUT);
    setInactivityTimer(timer);
  };

  // Check for saved authentication on component mount
  useEffect(() => {
    const savedAuth = localStorage.getItem('authData');
    if (savedAuth) {
      const authData = JSON.parse(savedAuth);
      if (authData.rememberMe) {
        setIsAuthenticated(true);
        setUser(authData.user);
        startInactivityTimer();
      }
    }
  }, []);

  // Add event listeners for user activity
  useEffect(() => {
    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    
    const resetTimer = () => {
      if (isAuthenticated) {
        resetInactivityTimer();
      }
    };

    events.forEach(event => {
      document.addEventListener(event, resetTimer, true);
    });

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, resetTimer, true);
      });
      if (inactivityTimer) {
        clearTimeout(inactivityTimer);
      }
    };
  }, [isAuthenticated, inactivityTimer]);

  return (
    <AuthContext.Provider value={{
      isAuthenticated,
      user,
      login,
      logout,
      resetInactivityTimer
    }}>
      {children}
    </AuthContext.Provider>
  );
};

/**
 * Custom hook to use authentication context
 */
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
