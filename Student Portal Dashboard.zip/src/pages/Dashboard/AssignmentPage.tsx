/**
 * Assignment page displaying all assignments with submission status
 */
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Progress } from '../../components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import {
  ClipboardCheck,
  Calendar,
  Upload,
  Download,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  Eye
} from 'lucide-react';

interface Assignment {
  id: string;
  title: string;
  courseCode: string;
  courseName: string;
  description: string;
  assignedDate: string;
  dueDate: string;
  maxMarks: number;
  obtainedMarks?: number;
  status: 'pending' | 'submitted' | 'graded' | 'overdue';
  submissionDate?: string;
  attachments: string[];
}

/**
 * Assignment page component with submission tracking
 */
const AssignmentPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('all');

  const assignments: Assignment[] = [
    {
      id: '1',
      title: 'Binary Search Tree Implementation',
      courseCode: 'CS201',
      courseName: 'Data Structures & Algorithms',
      description: 'Implement a binary search tree with insertion, deletion, and traversal operations.',
      assignedDate: '2025-01-20',
      dueDate: '2025-02-05',
      maxMarks: 25,
      obtainedMarks: 23,
      status: 'graded',
      submissionDate: '2025-02-03',
      attachments: ['BST_Implementation.java', 'test_cases.txt']
    },
    {
      id: '2',
      title: 'Database Design Project',
      courseCode: 'CS202',
      courseName: 'Database Management Systems',
      description: 'Design a complete database system for a library management system including ER diagrams and SQL queries.',
      assignedDate: '2025-01-25',
      dueDate: '2025-02-10',
      maxMarks: 30,
      status: 'submitted',
      submissionDate: '2025-02-08',
      attachments: ['library_db_design.pdf', 'queries.sql']
    },
    {
      id: '3',
      title: 'Process Scheduling Algorithms',
      courseCode: 'CS203',
      courseName: 'Operating Systems',
      description: 'Implement and compare different CPU scheduling algorithms (FCFS, SJF, Round Robin).',
      assignedDate: '2025-01-28',
      dueDate: '2025-02-15',
      maxMarks: 20,
      status: 'pending',
      attachments: ['scheduling_template.c', 'requirements.pdf']
    },
    {
      id: '4',
      title: 'Network Protocol Analysis',
      courseCode: 'CS204',
      courseName: 'Computer Networks',
      description: 'Analyze network packets using Wireshark and prepare a detailed report.',
      assignedDate: '2025-01-15',
      dueDate: '2025-01-30',
      maxMarks: 15,
      status: 'overdue',
      attachments: ['packet_capture.pcap', 'analysis_guide.pdf']
    },
    {
      id: '5',
      title: 'Software Requirements Document',
      courseCode: 'CS205',
      courseName: 'Software Engineering',
      description: 'Create a comprehensive Software Requirements Specification (SRS) document for an online shopping system.',
      assignedDate: '2025-02-01',
      dueDate: '2025-02-20',
      maxMarks: 35,
      status: 'pending',
      attachments: ['srs_template.docx', 'example_srs.pdf']
    },
    {
      id: '6',
      title: 'Responsive Web Design',
      courseCode: 'CS206',
      courseName: 'Web Technologies',
      description: 'Create a responsive website using HTML5, CSS3, and JavaScript.',
      assignedDate: '2025-01-30',
      dueDate: '2025-02-25',
      maxMarks: 25,
      status: 'pending',
      attachments: ['design_mockup.png', 'requirements.html']
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'graded': return 'bg-green-100 text-green-800';
      case 'submitted': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'graded': return <CheckCircle className="h-4 w-4" />;
      case 'submitted': return <Upload className="h-4 w-4" />;
      case 'overdue': return <AlertTriangle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getDaysRemaining = (dueDate: string) => {
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const filterAssignments = (status: string) => {
    if (status === 'all') return assignments;
    return assignments.filter(assignment => assignment.status === status);
  };

  const assignmentStats = {
    total: assignments.length,
    pending: assignments.filter(a => a.status === 'pending').length,
    submitted: assignments.filter(a => a.status === 'submitted').length,
    graded: assignments.filter(a => a.status === 'graded').length,
    overdue: assignments.filter(a => a.status === 'overdue').length
  };

  const totalMarks = assignments.filter(a => a.obtainedMarks).reduce((sum, a) => sum + (a.obtainedMarks || 0), 0);
  const maxPossibleMarks = assignments.filter(a => a.obtainedMarks).reduce((sum, a) => sum + a.maxMarks, 0);
  const averageScore = maxPossibleMarks > 0 ? Math.round((totalMarks / maxPossibleMarks) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Assignments</h1>
          <p className="text-gray-600">Track and submit your course assignments</p>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 rounded-full bg-blue-100">
                <ClipboardCheck className="h-5 w-5 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Total</p>
                <p className="text-xl font-bold text-gray-900">{assignmentStats.total}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 rounded-full bg-yellow-100">
                <Clock className="h-5 w-5 text-yellow-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Pending</p>
                <p className="text-xl font-bold text-gray-900">{assignmentStats.pending}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 rounded-full bg-blue-100">
                <Upload className="h-5 w-5 text-blue-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Submitted</p>
                <p className="text-xl font-bold text-gray-900">{assignmentStats.submitted}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 rounded-full bg-green-100">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Graded</p>
                <p className="text-xl font-bold text-gray-900">{assignmentStats.graded}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="p-2 rounded-full bg-red-100">
                <AlertTriangle className="h-5 w-5 text-red-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Overdue</p>
                <p className="text-xl font-bold text-gray-900">{assignmentStats.overdue}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">{averageScore}%</div>
              <div className="text-sm text-gray-600">Average Score</div>
              <Progress value={averageScore} className="mt-2" />
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">{totalMarks}</div>
              <div className="text-sm text-gray-600">Total Marks Obtained</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">{maxPossibleMarks}</div>
              <div className="text-sm text-gray-600">Maximum Possible Marks</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Assignments List */}
      <Card>
        <CardHeader>
          <CardTitle>All Assignments</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="all">All ({assignmentStats.total})</TabsTrigger>
              <TabsTrigger value="pending">Pending ({assignmentStats.pending})</TabsTrigger>
              <TabsTrigger value="submitted">Submitted ({assignmentStats.submitted})</TabsTrigger>
              <TabsTrigger value="graded">Graded ({assignmentStats.graded})</TabsTrigger>
              <TabsTrigger value="overdue">Overdue ({assignmentStats.overdue})</TabsTrigger>
            </TabsList>

            {['all', 'pending', 'submitted', 'graded', 'overdue'].map(status => (
              <TabsContent key={status} value={status} className="space-y-4 mt-6">
                {filterAssignments(status).map((assignment) => (
                  <div key={assignment.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-gray-900">{assignment.title}</h3>
                          <Badge variant="outline">{assignment.courseCode}</Badge>
                          <Badge className={getStatusColor(assignment.status)}>
                            <div className="flex items-center space-x-1">
                              {getStatusIcon(assignment.status)}
                              <span className="capitalize">{assignment.status}</span>
                            </div>
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{assignment.courseName}</p>
                        <p className="text-sm text-gray-700">{assignment.description}</p>
                      </div>
                      <div className="text-right ml-4">
                        <div className="text-lg font-semibold text-gray-900">
                          {assignment.obtainedMarks ? `${assignment.obtainedMarks}/` : ''}{assignment.maxMarks}
                        </div>
                        <div className="text-xs text-gray-500">marks</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                      <div>
                        <span className="text-gray-600">Assigned:</span>
                        <p className="font-medium">{new Date(assignment.assignedDate).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Due:</span>
                        <p className="font-medium">{new Date(assignment.dueDate).toLocaleDateString()}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Days Remaining:</span>
                        <p className={`font-medium ${getDaysRemaining(assignment.dueDate) < 0 ? 'text-red-600' : getDaysRemaining(assignment.dueDate) <= 3 ? 'text-yellow-600' : 'text-green-600'}`}>
                          {getDaysRemaining(assignment.dueDate) < 0 ? `${Math.abs(getDaysRemaining(assignment.dueDate))} overdue` : `${getDaysRemaining(assignment.dueDate)} days`}
                        </p>
                      </div>
                      <div>
                        <span className="text-gray-600">Submitted:</span>
                        <p className="font-medium">
                          {assignment.submissionDate ? new Date(assignment.submissionDate).toLocaleDateString() : 'Not submitted'}
                        </p>
                      </div>
                    </div>

                    {assignment.attachments.length > 0 && (
                      <div className="mb-4">
                        <span className="text-sm text-gray-600">Attachments:</span>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {assignment.attachments.map((file, index) => (
                            <Badge key={index} variant="outline" className="cursor-pointer hover:bg-gray-100">
                              <FileText className="mr-1 h-3 w-3" />
                              {file}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        <Eye className="mr-2 h-4 w-4" />
                        View Details
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                      {assignment.status === 'pending' && (
                        <Button size="sm">
                          <Upload className="mr-2 h-4 w-4" />
                          Submit
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default AssignmentPage;
