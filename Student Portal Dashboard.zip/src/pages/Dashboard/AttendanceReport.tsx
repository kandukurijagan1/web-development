/**
 * Attendance report page showing attendance percentage for each course
 */
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Progress } from '../../components/ui/progress';
import { Badge } from '../../components/ui/badge';
import { Calendar, TrendingUp, Clock, CheckCircle } from 'lucide-react';

interface AttendanceData {
  courseCode: string;
  courseName: string;
  totalClasses: number;
  attendedClasses: number;
  percentage: number;
  status: 'excellent' | 'good' | 'warning' | 'danger';
}

/**
 * Attendance report component with course-wise attendance display
 */
const AttendanceReport: React.FC = () => {
  const attendanceData: AttendanceData[] = [
    {
      courseCode: 'CS201',
      courseName: 'Data Structures & Algorithms',
      totalClasses: 45,
      attendedClasses: 38,
      percentage: 85,
      status: 'good'
    },
    {
      courseCode: 'CS202',
      courseName: 'Database Management Systems',
      totalClasses: 40,
      attendedClasses: 34,
      percentage: 85,
      status: 'good'
    },
    {
      courseCode: 'CS203',
      courseName: 'Operating Systems',
      totalClasses: 42,
      attendedClasses: 36,
      percentage: 85,
      status: 'good'
    },
    {
      courseCode: 'CS204',
      courseName: 'Computer Networks',
      totalClasses: 38,
      attendedClasses: 32,
      percentage: 85,
      status: 'good'
    },
    {
      courseCode: 'CS205',
      courseName: 'Software Engineering',
      totalClasses: 35,
      attendedClasses: 30,
      percentage: 85,
      status: 'good'
    },
    {
      courseCode: 'CS206',
      courseName: 'Web Technologies',
      totalClasses: 40,
      attendedClasses: 34,
      percentage: 85,
      status: 'good'
    },
    {
      courseCode: 'MA301',
      courseName: 'Discrete Mathematics',
      totalClasses: 36,
      attendedClasses: 31,
      percentage: 85,
      status: 'good'
    },
    {
      courseCode: 'CS207',
      courseName: 'Machine Learning',
      totalClasses: 32,
      attendedClasses: 27,
      percentage: 85,
      status: 'good'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'danger': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (percentage: number) => {
    if (percentage >= 90) return 'Excellent';
    if (percentage >= 80) return 'Good';
    if (percentage >= 75) return 'Warning';
    return 'Low';
  };

  const overallAttendance = Math.round(
    attendanceData.reduce((sum, course) => sum + course.percentage, 0) / attendanceData.length
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Attendance Report</h1>
          <p className="text-gray-600">View your attendance for all enrolled courses</p>
        </div>
      </div>

      {/* Overall Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100">
                <TrendingUp className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Overall Attendance</p>
                <p className="text-2xl font-bold text-gray-900">{overallAttendance}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Classes Attended</p>
                <p className="text-2xl font-bold text-gray-900">262</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100">
                <Calendar className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Classes</p>
                <p className="text-2xl font-bold text-gray-900">308</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-red-100">
                <Clock className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Classes Missed</p>
                <p className="text-2xl font-bold text-gray-900">46</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Course-wise Attendance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="mr-2 h-5 w-5" />
            Course-wise Attendance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {attendanceData.map((course) => (
              <div key={course.courseCode} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="font-semibold text-gray-900">{course.courseName}</h3>
                      <Badge variant="outline">{course.courseCode}</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">
                      {course.attendedClasses} / {course.totalClasses} classes attended
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-gray-900">{course.percentage}%</div>
                    <Badge className={getStatusColor(course.status)}>
                      {getStatusText(course.percentage)}
                    </Badge>
                  </div>
                </div>
                <Progress value={course.percentage} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Attendance Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle>Attendance Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Minimum Requirements</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Minimum 80% attendance required for exam eligibility</li>
                <li>• 85% and above: Excellent attendance</li>
                <li>• 80-84%: Good attendance</li>
                <li>• 75-79%: Warning - improve attendance</li>
                <li>• Below 75%: Not eligible for exams</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Important Notes</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Medical leave with proper documentation is excused</li>
                <li>• Attendance is updated daily after each class</li>
                <li>• Contact faculty for any attendance discrepancies</li>
                <li>• Regular attendance improves academic performance</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AttendanceReport;
