/**
 * Attendance request page for submitting attendance correction requests
 */
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Badge } from '../../components/ui/badge';
import { AlertCircle, Clock, CheckCircle, FileText } from 'lucide-react';
import { Alert, AlertDescription } from '../../components/ui/alert';

interface AttendanceRequest {
  id: string;
  courseCode: string;
  courseName: string;
  date: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedDate: string;
}

/**
 * Attendance request component for managing attendance corrections
 */
const AttendanceRequest: React.FC = () => {
  const [formData, setFormData] = useState({
    courseCode: '',
    date: '',
    reason: '',
    description: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  // Sample previous requests
  const previousRequests: AttendanceRequest[] = [
    {
      id: '1',
      courseCode: 'CS201',
      courseName: 'Data Structures & Algorithms',
      date: '2025-01-25',
      reason: 'Medical emergency',
      status: 'approved',
      submittedDate: '2025-01-26'
    },
    {
      id: '2',
      courseCode: 'CS202',
      courseName: 'Database Management Systems',
      date: '2025-01-20',
      reason: 'Family function',
      status: 'pending',
      submittedDate: '2025-01-21'
    },
    {
      id: '3',
      courseCode: 'CS203',
      courseName: 'Operating Systems',
      date: '2025-01-15',
      reason: 'Technical issue',
      status: 'rejected',
      submittedDate: '2025-01-16'
    }
  ];

  const courses = [
    { code: 'CS201', name: 'Data Structures & Algorithms' },
    { code: 'CS202', name: 'Database Management Systems' },
    { code: 'CS203', name: 'Operating Systems' },
    { code: 'CS204', name: 'Computer Networks' },
    { code: 'CS205', name: 'Software Engineering' },
    { code: 'CS206', name: 'Web Technologies' },
    { code: 'MA301', name: 'Discrete Mathematics' },
    { code: 'CS207', name: 'Machine Learning' }
  ];

  /**
   * Handle form submission for new attendance request
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));

    setShowSuccess(true);
    setFormData({ courseCode: '', date: '', reason: '', description: '' });
    setIsSubmitting(false);

    // Hide success message after 5 seconds
    setTimeout(() => setShowSuccess(false), 5000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'rejected': return <AlertCircle className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Attendance Request</h1>
          <p className="text-gray-600">Submit requests for attendance corrections</p>
        </div>
      </div>

      {showSuccess && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Your attendance request has been submitted successfully. You will receive an update within 2-3 business days.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* New Request Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="mr-2 h-5 w-5" />
              Submit New Request
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="course">Select Course</Label>
                <Select
                  value={formData.courseCode}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, courseCode: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a course" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((course) => (
                      <SelectItem key={course.code} value={course.code}>
                        {course.code} - {course.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="date">Class Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
                  max={new Date().toISOString().split('T')[0]}
                  required
                />
              </div>

              <div>
                <Label htmlFor="reason">Reason</Label>
                <Select
                  value={formData.reason}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, reason: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select reason" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="medical">Medical Emergency</SelectItem>
                    <SelectItem value="family">Family Function</SelectItem>
                    <SelectItem value="technical">Technical Issue</SelectItem>
                    <SelectItem value="transport">Transportation Problem</SelectItem>
                    <SelectItem value="university">University Work</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description">Additional Details</Label>
                <Textarea
                  id="description"
                  placeholder="Provide additional details about your request..."
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  rows={3}
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isSubmitting || !formData.courseCode || !formData.date || !formData.reason}
              >
                {isSubmitting ? 'Submitting...' : 'Submit Request'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Request Guidelines */}
        <Card>
          <CardHeader>
            <CardTitle>Request Guidelines</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Important Notes</h4>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Requests must be submitted within 7 days of the missed class</li>
                  <li>• Medical emergencies require proper documentation</li>
                  <li>• University-related activities need official confirmation</li>
                  <li>• Each request is reviewed by the respective faculty</li>
                  <li>• False information may lead to disciplinary action</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Processing Time</h4>
                <p className="text-sm text-gray-600">
                  Requests are typically processed within 2-3 business days. You will receive 
                  email notifications for status updates.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Required Documents</h4>
                <ul className="space-y-1 text-sm text-gray-600">
                  <li>• Medical: Doctor's certificate</li>
                  <li>• Family: Invitation or proof</li>
                  <li>• University: Official letter</li>
                  <li>• Transport: Route disruption proof</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Previous Requests */}
      <Card>
        <CardHeader>
          <CardTitle>Previous Requests</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {previousRequests.map((request) => (
              <div key={request.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h4 className="font-semibold text-gray-900">{request.courseName}</h4>
                    <p className="text-sm text-gray-600">
                      Class Date: {new Date(request.date).toLocaleDateString()} | 
                      Submitted: {new Date(request.submittedDate).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge className={getStatusColor(request.status)}>
                    <div className="flex items-center space-x-1">
                      {getStatusIcon(request.status)}
                      <span className="capitalize">{request.status}</span>
                    </div>
                  </Badge>
                </div>
                <p className="text-sm text-gray-700">
                  <strong>Reason:</strong> {request.reason}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AttendanceRequest;
