/**
 * Course feedback page for submitting and viewing course evaluations
 */
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Badge } from '../../components/ui/badge';
import { RadioGroup, RadioGroupItem } from '../../components/ui/radio-group';
import { MessageSquare, Star, CheckCircle, Clock, Send } from 'lucide-react';
import { Alert, AlertDescription } from '../../components/ui/alert';

interface Course {
  id: string;
  code: string;
  name: string;
  instructor: string;
  feedbackStatus: 'pending' | 'submitted' | 'closed';
}

interface FeedbackSubmission {
  courseId: string;
  ratings: { [key: string]: number };
  comments: string;
  submittedAt: string;
}

/**
 * Course feedback component for course evaluation
 */
const CourseFeedback: React.FC = () => {
  const [selectedCourse, setSelectedCourse] = useState('');
  const [ratings, setRatings] = useState<{ [key: string]: number }>({});
  const [comments, setComments] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const courses: Course[] = [
    {
      id: '1',
      code: 'CS201',
      name: 'Data Structures & Algorithms',
      instructor: 'Dr. Rajesh Kumar',
      feedbackStatus: 'pending'
    },
    {
      id: '2',
      code: 'CS202',
      name: 'Database Management Systems',
      instructor: 'Prof. Priya Sharma',
      feedbackStatus: 'pending'
    },
    {
      id: '3',
      code: 'CS203',
      name: 'Operating Systems',
      instructor: 'Dr. Amit Singh',
      feedbackStatus: 'submitted'
    },
    {
      id: '4',
      code: 'CS204',
      name: 'Computer Networks',
      instructor: 'Prof. Meera Patel',
      feedbackStatus: 'pending'
    },
    {
      id: '5',
      code: 'CS205',
      name: 'Software Engineering',
      instructor: 'Dr. Vikram Reddy',
      feedbackStatus: 'closed'
    }
  ];

  const feedbackQuestions = [
    {
      id: 'content_quality',
      question: 'How would you rate the quality of course content?',
      category: 'Content'
    },
    {
      id: 'teaching_effectiveness',
      question: 'How effective was the instructor\'s teaching method?',
      category: 'Teaching'
    },
    {
      id: 'course_organization',
      question: 'How well organized was the course structure?',
      category: 'Organization'
    },
    {
      id: 'assignments_relevance',
      question: 'How relevant were the assignments to course objectives?',
      category: 'Assignments'
    },
    {
      id: 'instructor_availability',
      question: 'How available was the instructor for questions and help?',
      category: 'Support'
    },
    {
      id: 'learning_outcomes',
      question: 'How well did this course meet the stated learning outcomes?',
      category: 'Outcomes'
    }
  ];

  const submittedFeedback: FeedbackSubmission[] = [
    {
      courseId: '3',
      ratings: {
        content_quality: 4,
        teaching_effectiveness: 5,
        course_organization: 4,
        assignments_relevance: 4,
        instructor_availability: 5,
        learning_outcomes: 4
      },
      comments: 'Excellent course with clear explanations and practical examples. The instructor was very helpful.',
      submittedAt: '2025-01-25'
    }
  ];

  /**
   * Handle feedback submission
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));

    setShowSuccess(true);
    setSelectedCourse('');
    setRatings({});
    setComments('');
    setIsSubmitting(false);

    // Hide success message after 5 seconds
    setTimeout(() => setShowSuccess(false), 5000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'submitted': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'closed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted': return <CheckCircle className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      default: return <MessageSquare className="h-4 w-4" />;
    }
  };

  const selectedCourseData = courses.find(c => c.id === selectedCourse);
  const canSubmitFeedback = selectedCourseData?.feedbackStatus === 'pending';

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Course Feedback</h1>
          <p className="text-gray-600">Provide feedback to help improve course quality</p>
        </div>
      </div>

      {showSuccess && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Your feedback has been submitted successfully. Thank you for your valuable input!
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Course Selection */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center">
              <MessageSquare className="mr-2 h-5 w-5" />
              Select Course
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {courses.map((course) => (
                <div
                  key={course.id}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedCourse === course.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedCourse(course.id)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{course.name}</h4>
                    <Badge className={getStatusColor(course.feedbackStatus)}>
                      <div className="flex items-center space-x-1">
                        {getStatusIcon(course.feedbackStatus)}
                        <span className="capitalize">{course.feedbackStatus}</span>
                      </div>
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">{course.code}</p>
                  <p className="text-sm text-gray-600">{course.instructor}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Feedback Form */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>
              {selectedCourseData ? `Feedback for ${selectedCourseData.name}` : 'Select a Course'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!selectedCourseData ? (
              <div className="text-center py-12">
                <MessageSquare className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No course selected</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Choose a course from the left panel to provide feedback
                </p>
              </div>
            ) : selectedCourseData.feedbackStatus === 'submitted' ? (
              <div className="text-center py-12">
                <CheckCircle className="mx-auto h-12 w-12 text-green-500" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">Feedback Already Submitted</h3>
                <p className="mt-1 text-sm text-gray-500">
                  You have already provided feedback for this course
                </p>
                {/* Show submitted feedback */}
                <div className="mt-6 text-left">
                  {submittedFeedback
                    .filter(f => f.courseId === selectedCourse)
                    .map((feedback, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <h4 className="font-medium mb-3">Your Previous Feedback</h4>
                        <div className="space-y-3">
                          {feedbackQuestions.map((question) => (
                            <div key={question.id} className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">{question.question}</span>
                              <div className="flex items-center">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <Star
                                    key={star}
                                    className={`h-4 w-4 ${
                                      star <= feedback.ratings[question.id]
                                        ? 'text-yellow-400 fill-current'
                                        : 'text-gray-300'
                                    }`}
                                  />
                                ))}
                              </div>
                            </div>
                          ))}
                          {feedback.comments && (
                            <div className="pt-3 border-t">
                              <p className="text-sm font-medium text-gray-700">Comments:</p>
                              <p className="text-sm text-gray-600 mt-1">{feedback.comments}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            ) : selectedCourseData.feedbackStatus === 'closed' ? (
              <div className="text-center py-12">
                <Clock className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">Feedback Period Closed</h3>
                <p className="mt-1 text-sm text-gray-500">
                  The feedback period for this course has ended
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-6">
                  {feedbackQuestions.map((question) => (
                    <div key={question.id} className="space-y-3">
                      <Label className="text-sm font-medium">{question.question}</Label>
                      <RadioGroup
                        value={ratings[question.id]?.toString() || ''}
                        onValueChange={(value) => setRatings(prev => ({ ...prev, [question.id]: parseInt(value) }))}
                        className="flex items-center space-x-4"
                      >
                        {[1, 2, 3, 4, 5].map((rating) => (
                          <div key={rating} className="flex items-center space-x-2">
                            <RadioGroupItem value={rating.toString()} id={`${question.id}-${rating}`} />
                            <Label htmlFor={`${question.id}-${rating}`} className="cursor-pointer">
                              <div className="flex items-center">
                                <Star className="h-4 w-4 text-yellow-400" />
                                <span className="ml-1 text-sm">{rating}</span>
                              </div>
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="comments">Additional Comments (Optional)</Label>
                  <Textarea
                    id="comments"
                    placeholder="Share any additional thoughts about the course..."
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    rows={4}
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isSubmitting || Object.keys(ratings).length !== feedbackQuestions.length}
                >
                  <Send className="mr-2 h-4 w-4" />
                  {isSubmitting ? 'Submitting Feedback...' : 'Submit Feedback'}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Feedback Statistics */}
      <Card>
        <CardHeader>
          <CardTitle>Feedback Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{courses.filter(c => c.feedbackStatus === 'submitted').length}</div>
              <div className="text-sm text-gray-600">Feedback Submitted</div>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">{courses.filter(c => c.feedbackStatus === 'pending').length}</div>
              <div className="text-sm text-gray-600">Pending Feedback</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-600">{courses.filter(c => c.feedbackStatus === 'closed').length}</div>
              <div className="text-sm text-gray-600">Feedback Closed</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CourseFeedback;
