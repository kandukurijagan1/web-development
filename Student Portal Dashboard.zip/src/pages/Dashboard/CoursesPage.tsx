/**
 * My Courses page displaying enrolled courses and their details
 */
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Progress } from '../../components/ui/progress';
import { BookOpen, Clock, Users, Award, Calendar, FileText } from 'lucide-react';

interface Course {
  id: string;
  code: string;
  name: string;
  instructor: string;
  credits: number;
  semester: string;
  progress: number;
  attendance: number;
  grade: string;
  status: 'ongoing' | 'completed' | 'upcoming';
  schedule: string;
  room: string;
}

/**
 * Courses page component displaying all enrolled courses
 */
const CoursesPage: React.FC = () => {
  const courses: Course[] = [
    {
      id: '1',
      code: 'CS201',
      name: 'Data Structures & Algorithms',
      instructor: 'Dr. Rajesh Kumar',
      credits: 4,
      semester: '6th Semester',
      progress: 92,
      attendance: 85,
      grade: 'A+',
      status: 'ongoing',
      schedule: 'Mon, Wed, Fri - 10:00 AM',
      room: 'CS Lab 1'
    },
    {
      id: '2',
      code: 'CS202',
      name: 'Database Management Systems',
      instructor: 'Prof. Priya Sharma',
      credits: 3,
      semester: '6th Semester',
      progress: 88,
      attendance: 85,
      grade: 'A',
      status: 'ongoing',
      schedule: 'Tue, Thu - 2:00 PM',
      room: 'Room 201'
    },
    {
      id: '3',
      code: 'CS203',
      name: 'Operating Systems',
      instructor: 'Dr. Amit Singh',
      credits: 3,
      semester: '6th Semester',
      progress: 85,
      attendance: 85,
      grade: 'A',
      status: 'ongoing',
      schedule: 'Mon, Wed - 11:00 AM',
      room: 'Room 203'
    },
    {
      id: '4',
      code: 'CS204',
      name: 'Computer Networks',
      instructor: 'Prof. Meera Patel',
      credits: 3,
      semester: '6th Semester',
      progress: 79,
      attendance: 85,
      grade: 'B+',
      status: 'ongoing',
      schedule: 'Tue, Thu - 10:00 AM',
      room: 'CS Lab 2'
    },
    {
      id: '5',
      code: 'CS205',
      name: 'Software Engineering',
      instructor: 'Dr. Vikram Reddy',
      credits: 3,
      semester: '6th Semester',
      progress: 90,
      attendance: 85,
      grade: 'A+',
      status: 'ongoing',
      schedule: 'Fri - 9:00 AM',
      room: 'Room 205'
    },
    {
      id: '6',
      code: 'CS206',
      name: 'Web Technologies',
      instructor: 'Prof. Sunita Gupta',
      credits: 3,
      semester: '6th Semester',
      progress: 87,
      attendance: 85,
      grade: 'A',
      status: 'ongoing',
      schedule: 'Wed, Fri - 2:00 PM',
      room: 'CS Lab 3'
    },
    {
      id: '7',
      code: 'MA301',
      name: 'Discrete Mathematics',
      instructor: 'Dr. Rahul Jain',
      credits: 4,
      semester: '6th Semester',
      progress: 82,
      attendance: 85,
      grade: 'B+',
      status: 'ongoing',
      schedule: 'Mon, Thu - 3:00 PM',
      room: 'Room 301'
    },
    {
      id: '8',
      code: 'CS207',
      name: 'Machine Learning',
      instructor: 'Prof. Anjali Verma',
      credits: 3,
      semester: '6th Semester',
      progress: 94,
      attendance: 85,
      grade: 'A+',
      status: 'ongoing',
      schedule: 'Tue, Fri - 11:00 AM',
      room: 'CS Lab 4'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ongoing': return 'bg-blue-100 text-blue-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'upcoming': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return 'text-green-600';
    if (grade.startsWith('B')) return 'text-blue-600';
    if (grade.startsWith('C')) return 'text-yellow-600';
    return 'text-red-600';
  };

  const totalCredits = courses.reduce((sum, course) => sum + course.credits, 0);
  const averageProgress = Math.round(courses.reduce((sum, course) => sum + course.progress, 0) / courses.length);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Courses</h1>
          <p className="text-gray-600">Manage your enrolled courses and track progress</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Courses</p>
                <p className="text-2xl font-bold text-gray-900">{courses.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100">
                <Award className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Credits</p>
                <p className="text-2xl font-bold text-gray-900">{totalCredits}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100">
                <Clock className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Avg Progress</p>
                <p className="text-2xl font-bold text-gray-900">{averageProgress}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-yellow-100">
                <Users className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Current CGPA</p>
                <p className="text-2xl font-bold text-gray-900">8.7</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {courses.map((course) => (
          <Card key={course.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{course.name}</CardTitle>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge variant="outline">{course.code}</Badge>
                    <Badge className={getStatusColor(course.status)}>
                      {course.status}
                    </Badge>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-xl font-bold ${getGradeColor(course.grade)}`}>
                    {course.grade}
                  </div>
                  <div className="text-xs text-gray-500">{course.credits} Credits</div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600">Instructor</p>
                    <p className="font-medium">{course.instructor}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Schedule</p>
                    <p className="font-medium">{course.schedule}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Room</p>
                    <p className="font-medium">{course.room}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Attendance</p>
                    <p className="font-medium">{course.attendance}%</p>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-600">Course Progress</span>
                    <span className="text-sm font-bold text-gray-900">{course.progress}%</span>
                  </div>
                  <Progress value={course.progress} className="h-2" />
                </div>

                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <FileText className="mr-2 h-4 w-4" />
                    Materials
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Calendar className="mr-2 h-4 w-4" />
                    Schedule
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Semester Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Semester Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{courses.length}</div>
              <div className="text-sm text-gray-600">Courses Enrolled</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{totalCredits}</div>
              <div className="text-sm text-gray-600">Total Credits</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">6th</div>
              <div className="text-sm text-gray-600">Current Semester</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CoursesPage;
