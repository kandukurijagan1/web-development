/**
 * Financial record page displaying fee payments and outstanding amounts
 */
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Progress } from '../../components/ui/progress';
import {
  CreditCard,
  DollarSign,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Download,
  Receipt
} from 'lucide-react';

interface PaymentRecord {
  id: string;
  description: string;
  amount: number;
  dueDate: string;
  paidDate?: string;
  status: 'paid' | 'pending' | 'overdue';
}

interface FeeStructure {
  category: string;
  amount: number;
  paid: number;
  status: 'paid' | 'partial' | 'pending';
}

/**
 * Financial record component showing fee payments and dues
 */
const FinancialRecord: React.FC = () => {
  const currentYear = '2024-25';
  const totalFees = 250000;
  const paidAmount = 50000;
  const pendingAmount = 200000;

  const feeStructure: FeeStructure[] = [
    {
      category: 'Tuition Fee',
      amount: 150000,
      paid: 30000,
      status: 'partial'
    },
    {
      category: 'Laboratory Fee',
      amount: 25000,
      paid: 5000,
      status: 'partial'
    },
    {
      category: 'Library Fee',
      amount: 10000,
      paid: 2000,
      status: 'partial'
    },
    {
      category: 'Development Fee',
      amount: 20000,
      paid: 4000,
      status: 'partial'
    },
    {
      category: 'Examination Fee',
      amount: 15000,
      paid: 3000,
      status: 'partial'
    },
    {
      category: 'Sports & Cultural Fee',
      amount: 8000,
      paid: 1600,
      status: 'partial'
    },
    {
      category: 'Medical Insurance',
      amount: 5000,
      paid: 1000,
      status: 'partial'
    },
    {
      category: 'Hostel Fee',
      amount: 17000,
      paid: 3400,
      status: 'partial'
    }
  ];

  const paymentHistory: PaymentRecord[] = [
    {
      id: '1',
      description: 'First Installment Payment',
      amount: 50000,
      dueDate: '2024-08-15',
      paidDate: '2024-08-10',
      status: 'paid'
    },
    {
      id: '2',
      description: 'Second Installment Payment',
      amount: 50000,
      dueDate: '2024-12-15',
      status: 'overdue'
    },
    {
      id: '3',
      description: 'Third Installment Payment',
      amount: 50000,
      dueDate: '2025-03-15',
      status: 'pending'
    },
    {
      id: '4',
      description: 'Final Installment Payment',
      amount: 50000,
      dueDate: '2025-06-15',
      status: 'pending'
    },
    {
      id: '5',
      description: 'Additional Fees',
      amount: 50000,
      dueDate: '2025-07-15',
      status: 'pending'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      case 'partial': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid': return <CheckCircle className="h-4 w-4" />;
      case 'overdue': return <AlertTriangle className="h-4 w-4" />;
      default: return <Calendar className="h-4 w-4" />;
    }
  };

  const paymentProgress = (paidAmount / totalFees) * 100;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Financial Record</h1>
          <p className="text-gray-600">Track your fee payments for academic year {currentYear}</p>
        </div>
        <Button>
          <Download className="mr-2 h-4 w-4" />
          Download Statement
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100">
                <DollarSign className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Fees</p>
                <p className="text-2xl font-bold text-gray-900">₹{totalFees.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Amount Paid</p>
                <p className="text-2xl font-bold text-gray-900">₹{paidAmount.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-red-100">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pending Amount</p>
                <p className="text-2xl font-bold text-gray-900">₹{pendingAmount.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100">
                <CreditCard className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Payment Progress</p>
                <p className="text-2xl font-bold text-gray-900">{Math.round(paymentProgress)}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-gray-600">Academic Year {currentYear}</span>
              <span className="text-sm font-bold text-gray-900">
                ₹{paidAmount.toLocaleString()} / ₹{totalFees.toLocaleString()}
              </span>
            </div>
            <Progress value={paymentProgress} className="h-3" />
            <div className="text-center">
              <span className="text-lg font-semibold text-red-600">
                Outstanding: ₹{pendingAmount.toLocaleString()}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fee Structure */}
        <Card>
          <CardHeader>
            <CardTitle>Fee Structure</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {feeStructure.map((fee, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">{fee.category}</h4>
                      <Badge className={getStatusColor(fee.status)}>
                        {fee.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600">
                      Paid: ₹{fee.paid.toLocaleString()} / ₹{fee.amount.toLocaleString()}
                    </div>
                    <Progress value={(fee.paid / fee.amount) * 100} className="h-1 mt-2" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Payment History */}
        <Card>
          <CardHeader>
            <CardTitle>Payment Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {paymentHistory.map((payment) => (
                <div key={payment.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-full ${getStatusColor(payment.status).replace('text-', 'text-').replace('bg-', 'bg-')}`}>
                      {getStatusIcon(payment.status)}
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">{payment.description}</h4>
                      <p className="text-sm text-gray-600">
                        Due: {new Date(payment.dueDate).toLocaleDateString()}
                        {payment.paidDate && (
                          <> | Paid: {new Date(payment.paidDate).toLocaleDateString()}</>
                        )}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-gray-900">₹{payment.amount.toLocaleString()}</div>
                    <Badge className={getStatusColor(payment.status)}>
                      {payment.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment Options */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Options</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button className="h-auto p-6 flex flex-col items-center space-y-2">
              <CreditCard className="h-8 w-8" />
              <span>Pay Online</span>
              <span className="text-xs opacity-75">Credit/Debit Card, UPI</span>
            </Button>
            
            <Button variant="outline" className="h-auto p-6 flex flex-col items-center space-y-2">
              <Receipt className="h-8 w-8" />
              <span>Bank Transfer</span>
              <span className="text-xs opacity-75">NEFT/RTGS/IMPS</span>
            </Button>
            
            <Button variant="outline" className="h-auto p-6 flex flex-col items-center space-y-2">
              <Download className="h-8 w-8" />
              <span>Challan</span>
              <span className="text-xs opacity-75">Download & Pay at Bank</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Important Notes */}
      <Card>
        <CardHeader>
          <CardTitle>Important Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Payment Guidelines</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Fees can be paid in installments as per schedule</li>
                <li>• Late payment charges apply after due date</li>
                <li>• No admission to examinations without fee clearance</li>
                <li>• Refunds processed as per university policy</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Contact Information</h4>
              <div className="space-y-2 text-sm text-gray-600">
                <p><strong>Accounts Office:</strong> +91 12345 67890</p>
                <p><strong>Email:</strong> accounts@university.edu.in</p>
                <p><strong>Office Hours:</strong> 9:00 AM - 5:00 PM</p>
                <p><strong>Address:</strong> Administration Building, Ground Floor</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FinancialRecord;
