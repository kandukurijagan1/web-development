/**
 * Internal marks page displaying semester examination results
 */
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Progress } from '../../components/ui/progress';
import { Button } from '../../components/ui/button';
import {
  GraduationCap,
  TrendingUp,
  Award,
  BarChart3,
  Download,
  Eye,
  Calculator
} from 'lucide-react';

interface InternalMark {
  courseCode: string;
  courseName: string;
  credits: number;
  test1: number;
  test2: number;
  assignment: number;
  total: number;
  maxMarks: number;
  percentage: number;
  grade: string;
  gradePoints: number;
}

interface SemesterResult {
  semester: string;
  sgpa: number;
  totalCredits: number;
  status: 'completed' | 'current';
}

/**
 * Internal marks component showing examination results
 */
const InternalMarks: React.FC = () => {
  const currentSemesterMarks: InternalMark[] = [
    {
      courseCode: 'CS201',
      courseName: 'Data Structures & Algorithms',
      credits: 4,
      test1: 18,
      test2: 19,
      assignment: 23,
      total: 60,
      maxMarks: 75,
      percentage: 80,
      grade: 'A',
      gradePoints: 8
    },
    {
      courseCode: 'CS202',
      courseName: 'Database Management Systems',
      credits: 3,
      test1: 17,
      test2: 18,
      assignment: 22,
      total: 57,
      maxMarks: 75,
      percentage: 76,
      grade: 'B+',
      gradePoints: 7
    },
    {
      courseCode: 'CS203',
      courseName: 'Operating Systems',
      credits: 3,
      test1: 19,
      test2: 17,
      assignment: 21,
      total: 57,
      maxMarks: 75,
      percentage: 76,
      grade: 'B+',
      gradePoints: 7
    },
    {
      courseCode: 'CS204',
      courseName: 'Computer Networks',
      credits: 3,
      test1: 16,
      test2: 17,
      assignment: 20,
      total: 53,
      maxMarks: 75,
      percentage: 71,
      grade: 'B',
      gradePoints: 6
    },
    {
      courseCode: 'CS205',
      courseName: 'Software Engineering',
      credits: 3,
      test1: 20,
      test2: 19,
      assignment: 24,
      total: 63,
      maxMarks: 75,
      percentage: 84,
      grade: 'A',
      gradePoints: 8
    },
    {
      courseCode: 'CS206',
      courseName: 'Web Technologies',
      credits: 3,
      test1: 18,
      test2: 19,
      assignment: 22,
      total: 59,
      maxMarks: 75,
      percentage: 79,
      grade: 'B+',
      gradePoints: 7
    },
    {
      courseCode: 'MA301',
      courseName: 'Discrete Mathematics',
      credits: 4,
      test1: 17,
      test2: 16,
      assignment: 19,
      total: 52,
      maxMarks: 75,
      percentage: 69,
      grade: 'B',
      gradePoints: 6
    },
    {
      courseCode: 'CS207',
      courseName: 'Machine Learning',
      credits: 3,
      test1: 20,
      test2: 20,
      assignment: 25,
      total: 65,
      maxMarks: 75,
      percentage: 87,
      grade: 'A+',
      gradePoints: 9
    }
  ];

  const semesterResults: SemesterResult[] = [
    { semester: '1st Semester', sgpa: 8.2, totalCredits: 20, status: 'completed' },
    { semester: '2nd Semester', sgpa: 8.5, totalCredits: 22, status: 'completed' },
    { semester: '3rd Semester', sgpa: 8.7, totalCredits: 24, status: 'completed' },
    { semester: '4th Semester', sgpa: 8.9, totalCredits: 26, status: 'completed' },
    { semester: '5th Semester', sgpa: 8.6, totalCredits: 25, status: 'completed' },
    { semester: '6th Semester', sgpa: 0, totalCredits: 26, status: 'current' }
  ];

  const getGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return 'bg-green-100 text-green-800';
    if (grade.startsWith('B')) return 'bg-blue-100 text-blue-800';
    if (grade.startsWith('C')) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  // Calculate current semester SGPA
  const totalCredits = currentSemesterMarks.reduce((sum, mark) => sum + mark.credits, 0);
  const totalGradePoints = currentSemesterMarks.reduce((sum, mark) => sum + (mark.gradePoints * mark.credits), 0);
  const currentSGPA = totalCredits > 0 ? (totalGradePoints / totalCredits).toFixed(2) : '0.00';

  // Calculate CGPA
  const completedSemesters = semesterResults.filter(s => s.status === 'completed');
  const totalCompletedCredits = completedSemesters.reduce((sum, sem) => sum + sem.totalCredits, 0);
  const totalCompletedGradePoints = completedSemesters.reduce((sum, sem) => sum + (sem.sgpa * sem.totalCredits), 0);
  const cgpa = totalCompletedCredits > 0 ? (totalCompletedGradePoints / totalCompletedCredits).toFixed(2) : '0.00';

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Internal Marks</h1>
          <p className="text-gray-600">View your internal examination results and grades</p>
        </div>
        <Button>
          <Download className="mr-2 h-4 w-4" />
          Download Report
        </Button>
      </div>

      {/* Performance Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100">
                <GraduationCap className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Current SGPA</p>
                <p className="text-2xl font-bold text-gray-900">{currentSGPA}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100">
                <Award className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">CGPA</p>
                <p className="text-2xl font-bold text-gray-900">{cgpa}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100">
                <BarChart3 className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Credits</p>
                <p className="text-2xl font-bold text-gray-900">{totalCredits}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-yellow-100">
                <TrendingUp className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Average %</p>
                <p className="text-2xl font-bold text-gray-900">
                  {Math.round(currentSemesterMarks.reduce((sum, mark) => sum + mark.percentage, 0) / currentSemesterMarks.length)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Current Semester Marks */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calculator className="mr-2 h-5 w-5" />
            6th Semester - Internal Marks
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b">
                  <th className="pb-3 text-sm font-medium text-gray-600">Course</th>
                  <th className="pb-3 text-sm font-medium text-gray-600">Credits</th>
                  <th className="pb-3 text-sm font-medium text-gray-600">Test 1</th>
                  <th className="pb-3 text-sm font-medium text-gray-600">Test 2</th>
                  <th className="pb-3 text-sm font-medium text-gray-600">Assignment</th>
                  <th className="pb-3 text-sm font-medium text-gray-600">Total</th>
                  <th className="pb-3 text-sm font-medium text-gray-600">Percentage</th>
                  <th className="pb-3 text-sm font-medium text-gray-600">Grade</th>
                  <th className="pb-3 text-sm font-medium text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentSemesterMarks.map((mark, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    <td className="py-4">
                      <div>
                        <div className="font-medium text-gray-900">{mark.courseName}</div>
                        <div className="text-sm text-gray-600">{mark.courseCode}</div>
                      </div>
                    </td>
                    <td className="py-4 text-sm text-gray-900">{mark.credits}</td>
                    <td className="py-4 text-sm text-gray-900">{mark.test1}/25</td>
                    <td className="py-4 text-sm text-gray-900">{mark.test2}/25</td>
                    <td className="py-4 text-sm text-gray-900">{mark.assignment}/25</td>
                    <td className="py-4">
                      <div className="font-medium text-gray-900">{mark.total}/{mark.maxMarks}</div>
                      <Progress value={(mark.total / mark.maxMarks) * 100} className="w-20 h-1 mt-1" />
                    </td>
                    <td className="py-4 text-sm font-medium text-gray-900">{mark.percentage}%</td>
                    <td className="py-4">
                      <Badge className={getGradeColor(mark.grade)}>
                        {mark.grade}
                      </Badge>
                    </td>
                    <td className="py-4">
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Semester-wise Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Semester-wise Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {semesterResults.map((semester, index) => (
              <div
                key={index}
                className={`p-4 border rounded-lg ${
                  semester.status === 'current' ? 'border-blue-300 bg-blue-50' : 'border-gray-200'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-gray-900">{semester.semester}</h4>
                  <Badge variant={semester.status === 'current' ? 'default' : 'outline'}>
                    {semester.status === 'current' ? 'Current' : 'Completed'}
                  </Badge>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">SGPA:</span>
                    <span className="font-medium">
                      {semester.status === 'current' ? currentSGPA : semester.sgpa.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Credits:</span>
                    <span className="font-medium">{semester.totalCredits}</span>
                  </div>
                  <Progress
                    value={semester.status === 'current' ? parseFloat(currentSGPA) * 10 : semester.sgpa * 10}
                    className="h-2"
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Grade Scale */}
      <Card>
        <CardHeader>
          <CardTitle>Grading Scale</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="font-bold text-green-700">A+</div>
              <div className="text-sm text-gray-600">90-100%</div>
              <div className="text-xs text-gray-500">9-10 Points</div>
            </div>
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="font-bold text-green-700">A</div>
              <div className="text-sm text-gray-600">80-89%</div>
              <div className="text-xs text-gray-500">8 Points</div>
            </div>
            <div className="text-center p-3 bg-blue-50 rounded-lg">
              <div className="font-bold text-blue-700">B+</div>
              <div className="text-sm text-gray-600">70-79%</div>
              <div className="text-xs text-gray-500">7 Points</div>
            </div>
            <div className="text-center p-3 bg-blue-50 rounded-lg">
              <div className="font-bold text-blue-700">B</div>
              <div className="text-sm text-gray-600">60-69%</div>
              <div className="text-xs text-gray-500">6 Points</div>
            </div>
            <div className="text-center p-3 bg-yellow-50 rounded-lg">
              <div className="font-bold text-yellow-700">C</div>
              <div className="text-sm text-gray-600">50-59%</div>
              <div className="text-xs text-gray-500">5 Points</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InternalMarks;
