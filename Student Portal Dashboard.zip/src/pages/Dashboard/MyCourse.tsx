/**
 * My Course page displaying current semester course details and progress
 */
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Progress } from '../../components/ui/progress';
import { 
  BookOpen, 
  Clock, 
  Users, 
  Calendar,
  MapPin,
  Star,
  TrendingUp,
  FileText,
  Video,
  MessageSquare
} from 'lucide-react';

interface Course {
  id: string;
  code: string;
  name: string;
  instructor: string;
  credits: number;
  schedule: string;
  room: string;
  description: string;
  progress: number;
  attendance: number;
  assignments: number;
  nextClass: string;
  syllabus: string[];
  currentTopic: string;
  upcomingTests: string[];
}

/**
 * My Course component showing detailed current semester courses
 */
const MyCourse: React.FC = () => {
  const currentCourses: Course[] = [
    {
      id: '1',
      code: 'CS201',
      name: 'Data Structures & Algorithms',
      instructor: 'Dr. Rajesh Kumar',
      credits: 4,
      schedule: 'Mon, Wed, Fri - 10:00 AM',
      room: 'CS Lab 1',
      description: 'Comprehensive study of fundamental data structures including arrays, linked lists, stacks, queues, trees, and graphs. Implementation and analysis of various algorithms.',
      progress: 92,
      attendance: 85,
      assignments: 3,
      nextClass: 'Tomorrow at 10:00 AM',
      syllabus: ['Arrays & Linked Lists', 'Stacks & Queues', 'Trees', 'Graphs', 'Sorting Algorithms', 'Searching Algorithms'],
      currentTopic: 'Graph Algorithms - DFS & BFS',
      upcomingTests: ['Mid-term Exam - Feb 15', 'Assignment 4 - Feb 20']
    },
    {
      id: '2',
      code: 'CS202',
      name: 'Database Management Systems',
      instructor: 'Prof. Priya Sharma',
      credits: 3,
      schedule: 'Tue, Thu - 2:00 PM',
      room: 'Room 201',
      description: 'Introduction to database concepts, relational model, SQL, normalization, transaction management, and database design principles.',
      progress: 88,
      attendance: 85,
      assignments: 2,
      nextClass: 'Thursday at 2:00 PM',
      syllabus: ['Database Concepts', 'Relational Model', 'SQL Queries', 'Normalization', 'Transactions', 'Indexing'],
      currentTopic: 'Database Normalization - 3NF & BCNF',
      upcomingTests: ['Quiz 3 - Feb 12', 'Project Submission - Feb 25']
    },
    {
      id: '3',
      code: 'CS203',
      name: 'Operating Systems',
      instructor: 'Dr. Amit Singh',
      credits: 3,
      schedule: 'Mon, Wed - 11:00 AM',
      room: 'Room 203',
      description: 'Study of operating system concepts including process management, memory management, file systems, and synchronization.',
      progress: 85,
      attendance: 85,
      assignments: 4,
      nextClass: 'Monday at 11:00 AM',
      syllabus: ['Process Management', 'CPU Scheduling', 'Memory Management', 'File Systems', 'Synchronization', 'Deadlocks'],
      currentTopic: 'Memory Management - Paging & Segmentation',
      upcomingTests: ['Lab Exam - Feb 18', 'Theory Test - Feb 22']
    },
    {
      id: '4',
      code: 'CS204',
      name: 'Computer Networks',
      instructor: 'Prof. Meera Patel',
      credits: 3,
      schedule: 'Tue, Thu - 10:00 AM',
      room: 'CS Lab 2',
      description: 'Fundamentals of computer networking including OSI model, TCP/IP, routing protocols, and network security.',
      progress: 79,
      attendance: 85,
      assignments: 2,
      nextClass: 'Tuesday at 10:00 AM',
      syllabus: ['Network Basics', 'OSI Model', 'TCP/IP', 'Routing', 'Network Security', 'Wireless Networks'],
      currentTopic: 'Routing Protocols - RIP & OSPF',
      upcomingTests: ['Network Lab - Feb 14', 'Mid-term - Feb 28']
    }
  ];

  const totalCredits = currentCourses.reduce((sum, course) => sum + course.credits, 0);
  const averageProgress = Math.round(currentCourses.reduce((sum, course) => sum + course.progress, 0) / currentCourses.length);
  const totalAssignments = currentCourses.reduce((sum, course) => sum + course.assignments, 0);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Course</h1>
          <p className="text-gray-600">Current semester courses and detailed progress</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-blue-100">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Active Courses</p>
                <p className="text-2xl font-bold text-gray-900">{currentCourses.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-green-100">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Avg Progress</p>
                <p className="text-2xl font-bold text-gray-900">{averageProgress}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-purple-100">
                <Star className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Credits</p>
                <p className="text-2xl font-bold text-gray-900">{totalCredits}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-3 rounded-full bg-yellow-100">
                <FileText className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Assignments</p>
                <p className="text-2xl font-bold text-gray-900">{totalAssignments}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Current Courses */}
      <div className="space-y-6">
        {currentCourses.map((course) => (
          <Card key={course.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl">{course.name}</CardTitle>
                  <div className="flex items-center space-x-2 mt-2">
                    <Badge variant="outline">{course.code}</Badge>
                    <Badge className="bg-blue-100 text-blue-800">{course.credits} Credits</Badge>
                    <Badge className="bg-green-100 text-green-800">{course.attendance}% Attendance</Badge>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-indigo-600">{course.progress}%</div>
                  <div className="text-xs text-gray-500">Progress</div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Course Description */}
                <p className="text-gray-700">{course.description}</p>

                {/* Course Details Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Instructor</p>
                      <p className="font-medium">{course.instructor}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Schedule</p>
                      <p className="font-medium">{course.schedule}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Room</p>
                      <p className="font-medium">{course.room}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-600">Next Class</p>
                      <p className="font-medium">{course.nextClass}</p>
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-600">Course Progress</span>
                    <span className="text-sm font-bold text-gray-900">{course.progress}%</span>
                  </div>
                  <Progress value={course.progress} className="h-3" />
                </div>

                {/* Current Topic */}
                <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                  <h4 className="font-semibold text-indigo-900 mb-1">Current Topic</h4>
                  <p className="text-indigo-800">{course.currentTopic}</p>
                </div>

                {/* Syllabus Progress */}
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Syllabus Progress</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {course.syllabus.map((topic, index) => (
                      <div
                        key={index}
                        className={`p-2 rounded text-sm ${
                          index < Math.floor((course.progress / 100) * course.syllabus.length)
                            ? 'bg-green-100 text-green-800'
                            : index === Math.floor((course.progress / 100) * course.syllabus.length)
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {topic}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Upcoming Tests */}
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Upcoming Tests & Deadlines</h4>
                  <div className="space-y-2">
                    {course.upcomingTests.map((test, index) => (
                      <div key={index} className="flex items-center p-2 bg-yellow-50 border border-yellow-200 rounded">
                        <Calendar className="h-4 w-4 text-yellow-600 mr-2" />
                        <span className="text-yellow-800">{test}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm">
                    <FileText className="mr-2 h-4 w-4" />
                    Course Materials
                  </Button>
                  <Button variant="outline" size="sm">
                    <Video className="mr-2 h-4 w-4" />
                    Recorded Lectures
                  </Button>
                  <Button variant="outline" size="sm">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Discussion Forum
                  </Button>
                  <Button variant="outline" size="sm">
                    <Star className="mr-2 h-4 w-4" />
                    Submit Feedback
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button className="h-auto p-4 flex flex-col items-center space-y-2">
              <Calendar className="h-6 w-6" />
              <span className="text-sm">View Timetable</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
              <FileText className="h-6 w-6" />
              <span className="text-sm">Download Notes</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
              <Video className="h-6 w-6" />
              <span className="text-sm">Join Online Class</span>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
              <MessageSquare className="h-6 w-6" />
              <span className="text-sm">Ask Doubts</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MyCourse;
