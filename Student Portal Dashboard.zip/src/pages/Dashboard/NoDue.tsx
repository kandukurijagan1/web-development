/**
 * No Due certificate page for requesting and viewing no due certificates
 */
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Textarea } from '../../components/ui/textarea';
import { Label } from '../../components/ui/label';
import {
  ClipboardCheck,
  Download,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  Building,
  Printer
} from 'lucide-react';
import { Alert, AlertDescription } from '../../components/ui/alert';

interface Department {
  id: string;
  name: string;
  status: 'cleared' | 'pending' | 'dues';
  dueAmount?: number;
  remarks?: string;
}

interface NoDueRequest {
  id: string;
  requestType: string;
  requestDate: string;
  status: 'pending' | 'approved' | 'rejected';
  completedDate?: string;
  certificateNumber?: string;
}

/**
 * No Due certificate component for clearance requests
 */
const NoDue: React.FC = () => {
  const [requestType, setRequestType] = useState('');
  const [purpose, setPurpose] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const departments: Department[] = [
    {
      id: '1',
      name: 'Library',
      status: 'cleared',
      remarks: 'All books returned. No pending dues.'
    },
    {
      id: '2',
      name: 'Laboratory',
      status: 'cleared',
      remarks: 'All equipment returned in good condition.'
    },
    {
      id: '3',
      name: 'Hostel',
      status: 'pending',
      remarks: 'Verification in progress.'
    },
    {
      id: '4',
      name: 'Accounts Department',
      status: 'dues',
      dueAmount: 200000,
      remarks: 'Fee payment pending for current semester.'
    },
    {
      id: '5',
      name: 'Sports Department',
      status: 'cleared',
      remarks: 'All sports equipment returned.'
    },
    {
      id: '6',
      name: 'Placement Cell',
      status: 'cleared',
      remarks: 'All documents verified.'
    },
    {
      id: '7',
      name: 'Transport',
      status: 'cleared',
      remarks: 'No pending dues for bus services.'
    },
    {
      id: '8',
      name: 'Student Activities',
      status: 'cleared',
      remarks: 'All club activities completed.'
    }
  ];

  const previousRequests: NoDueRequest[] = [
    {
      id: '1',
      requestType: 'Internship',
      requestDate: '2025-01-15',
      status: 'approved',
      completedDate: '2025-01-20',
      certificateNumber: 'NDC/2025/001234'
    },
    {
      id: '2',
      requestType: 'Semester End',
      requestDate: '2025-01-25',
      status: 'pending'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'cleared': case 'approved': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'dues': case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'cleared': case 'approved': return <CheckCircle className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'dues': case 'rejected': return <AlertTriangle className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));

    setShowSuccess(true);
    setRequestType('');
    setPurpose('');
    setIsSubmitting(false);

    // Hide success message after 5 seconds
    setTimeout(() => setShowSuccess(false), 5000);
  };

  const clearanceStatus = {
    total: departments.length,
    cleared: departments.filter(d => d.status === 'cleared').length,
    pending: departments.filter(d => d.status === 'pending').length,
    dues: departments.filter(d => d.status === 'dues').length
  };

  const overallStatus = clearanceStatus.dues > 0 ? 'dues' : clearanceStatus.pending > 0 ? 'pending' : 'cleared';

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">No Due Certificate</h1>
          <p className="text-gray-600">Request and track no due certificate status</p>
        </div>
      </div>

      {showSuccess && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Your no due certificate request has been submitted successfully. You will receive updates via email.
          </AlertDescription>
        </Alert>
      )}

      {/* Overall Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <ClipboardCheck className="mr-2 h-5 w-5" />
              Clearance Status
            </span>
            <Badge className={getStatusColor(overallStatus)} variant="outline">
              <div className="flex items-center space-x-1">
                {getStatusIcon(overallStatus)}
                <span className="capitalize">{overallStatus === 'dues' ? 'Dues Pending' : overallStatus}</span>
              </div>
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{clearanceStatus.total}</div>
              <div className="text-sm text-gray-600">Total Departments</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{clearanceStatus.cleared}</div>
              <div className="text-sm text-gray-600">Cleared</div>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">{clearanceStatus.pending}</div>
              <div className="text-sm text-gray-600">Pending</div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{clearanceStatus.dues}</div>
              <div className="text-sm text-gray-600">Dues</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {departments.map((dept) => (
              <div key={dept.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Building className="h-4 w-4 text-gray-600" />
                    <h4 className="font-medium text-gray-900">{dept.name}</h4>
                  </div>
                  <Badge className={getStatusColor(dept.status)}>
                    <div className="flex items-center space-x-1">
                      {getStatusIcon(dept.status)}
                      <span className="capitalize">{dept.status}</span>
                    </div>
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">{dept.remarks}</p>
                {dept.dueAmount && (
                  <p className="text-sm font-medium text-red-600 mt-1">
                    Due Amount: ₹{dept.dueAmount.toLocaleString()}
                  </p>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* New Request Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="mr-2 h-5 w-5" />
              Request No Due Certificate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="requestType">Certificate Type</Label>
                <Select value={requestType} onValueChange={setRequestType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select certificate type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="internship">Internship</SelectItem>
                    <SelectItem value="placement">Placement</SelectItem>
                    <SelectItem value="semester_end">Semester End</SelectItem>
                    <SelectItem value="course_completion">Course Completion</SelectItem>
                    <SelectItem value="transfer">Transfer Certificate</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="purpose">Purpose</Label>
                <Textarea
                  id="purpose"
                  placeholder="Specify the purpose for requesting no due certificate..."
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  rows={3}
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isSubmitting || !requestType || !purpose || overallStatus !== 'cleared'}
              >
                {isSubmitting ? 'Submitting Request...' : 'Submit Request'}
              </Button>

              {overallStatus !== 'cleared' && (
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    You cannot request a no due certificate until all departments clear your dues and complete verification.
                  </AlertDescription>
                </Alert>
              )}
            </form>
          </CardContent>
        </Card>

        {/* Previous Requests */}
        <Card>
          <CardHeader>
            <CardTitle>Previous Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {previousRequests.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="mx-auto h-8 w-8 text-gray-400" />
                  <p className="text-sm text-gray-500 mt-2">No previous requests found</p>
                </div>
              ) : (
                previousRequests.map((request) => (
                  <div key={request.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">{request.requestType}</h4>
                      <Badge className={getStatusColor(request.status)}>
                        <div className="flex items-center space-x-1">
                          {getStatusIcon(request.status)}
                          <span className="capitalize">{request.status}</span>
                        </div>
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>Requested: {new Date(request.requestDate).toLocaleDateString()}</p>
                      {request.completedDate && (
                        <p>Completed: {new Date(request.completedDate).toLocaleDateString()}</p>
                      )}
                      {request.certificateNumber && (
                        <p>Certificate No: {request.certificateNumber}</p>
                      )}
                    </div>
                    {request.status === 'approved' && (
                      <div className="mt-3 flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                        <Button variant="outline" size="sm">
                          <Printer className="mr-2 h-4 w-4" />
                          Print
                        </Button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Important Information */}
      <Card>
        <CardHeader>
          <CardTitle>Important Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Processing Timeline</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Department verification: 2-3 working days</li>
                <li>• Certificate generation: 1-2 working days</li>
                <li>• Total processing time: 3-5 working days</li>
                <li>• Rush requests may be processed faster</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Requirements</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• All department dues must be cleared</li>
                <li>• Valid purpose for the certificate</li>
                <li>• Identity verification required</li>
                <li>• Original documents may be needed</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NoDue;
