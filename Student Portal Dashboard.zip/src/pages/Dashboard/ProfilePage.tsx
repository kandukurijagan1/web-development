/**
 * User profile page displaying personal information and profile picture
 */
import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '../../components/ui/avatar';
import { Badge } from '../../components/ui/badge';
import {
  User,
  Mail,
  Calendar,
  MapPin,
  Phone,
  BookOpen,
  GraduationCap,
  Award
} from 'lucide-react';

/**
 * Profile page component with personal information display
 */
const ProfilePage: React.FC = () => {
  const { user } = useAuth();

  const profileData = {
    studentId: user?.id || '192472374',
    name: user?.name || 'Kandukuri Jagan',
    email: user?.email || 'kandukurijagan99@gmail.com',
    dateOfBirth: user?.dateOfBirth || '14/06/2006',
    address: user?.address || 'balijapalem village, varadaiah palem mandal, tirupati district, Andhra Pradesh',
    phone: '+91 9876543210',
    course: 'Bachelor of Technology',
    branch: 'Computer Science Engineering',
    semester: '6th Semester',
    academicYear: '2023-2024',
    admissionDate: '15/08/2021',
    bloodGroup: 'B+',
    fatherName: 'Kandukuri Ramesh',
    motherName: 'Kandukuri Lakshmi',
    guardianPhone: '+91 9876543211'
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
          <p className="text-gray-600">Manage your personal information and academic details</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Picture and Basic Info */}
        <Card className="lg:col-span-1">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Avatar className="h-32 w-32">
                <AvatarImage 
                  src="https://pub-cdn.sider.ai/u/U05XH9OLR1Z/web-coder/688b8418db5e5041bf05b4c5/resource/622e9688-9093-4bdf-83e2-b73c2a8f3174.jpg" 
                  alt={profileData.name}
                  className="object-cover"
                />
                <AvatarFallback className="text-2xl">
                  {profileData.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
            </div>
            <CardTitle className="text-xl">{profileData.name}</CardTitle>
            <p className="text-gray-600">Student ID: {profileData.studentId}</p>
            <Badge variant="secondary" className="mt-2">
              {profileData.branch}
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center text-sm">
                <BookOpen className="h-4 w-4 mr-2 text-gray-500" />
                <span>{profileData.course}</span>
              </div>
              <div className="flex items-center text-sm">
                <GraduationCap className="h-4 w-4 mr-2 text-gray-500" />
                <span>{profileData.semester}</span>
              </div>
              <div className="flex items-center text-sm">
                <Award className="h-4 w-4 mr-2 text-gray-500" />
                <span>CGPA: 8.7</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Personal Information */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <User className="mr-2 h-5 w-5" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">Full Name</label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.name}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 flex items-center">
                    <Mail className="mr-1 h-4 w-4" />
                    Email Address
                  </label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.email}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 flex items-center">
                    <Calendar className="mr-1 h-4 w-4" />
                    Date of Birth
                  </label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.dateOfBirth}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 flex items-center">
                    <Phone className="mr-1 h-4 w-4" />
                    Phone Number
                  </label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.phone}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Blood Group</label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.bloodGroup}</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">Student ID</label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.studentId}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Academic Year</label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.academicYear}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Admission Date</label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.admissionDate}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Father's Name</label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.fatherName}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Mother's Name</label>
                  <p className="mt-1 text-sm text-gray-900">{profileData.motherName}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Address Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MapPin className="mr-2 h-5 w-5" />
            Address Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-sm font-medium text-gray-700">Permanent Address</label>
              <p className="mt-1 text-sm text-gray-900">{profileData.address}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">Guardian Contact</label>
              <p className="mt-1 text-sm text-gray-900">{profileData.guardianPhone}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Academic Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <GraduationCap className="mr-2 h-5 w-5" />
            Academic Details
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">8.7</div>
              <div className="text-sm text-gray-600">Current CGPA</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">85%</div>
              <div className="text-sm text-gray-600">Attendance</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">8</div>
              <div className="text-sm text-gray-600">Courses Enrolled</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfilePage;
