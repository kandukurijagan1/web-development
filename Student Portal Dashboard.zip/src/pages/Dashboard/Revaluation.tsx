/**
 * Revaluation page for requesting examination paper revaluation
 */
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Textarea } from '../../components/ui/textarea';
import { Label } from '../../components/ui/label';
import { Checkbox } from '../../components/ui/checkbox';
import {
  FileText,
  RefreshCw,
  CheckCircle,
  Clock,
  AlertTriangle,
  DollarSign,
  Calendar,
  Eye
} from 'lucide-react';
import { Alert, AlertDescription } from '../../components/ui/alert';

interface ExamResult {
  id: string;
  courseCode: string;
  courseName: string;
  examType: 'midterm' | 'endterm' | 'internal';
  semester: string;
  marksObtained: number;
  maxMarks: number;
  percentage: number;
  grade: string;
  examDate: string;
  resultDate: string;
  canApplyRevaluation: boolean;
}

interface RevaluationRequest {
  id: string;
  courseCode: string;
  courseName: string;
  examType: string;
  semester: string;
  originalMarks: number;
  newMarks?: number;
  revaluationFee: number;
  requestDate: string;
  status: 'pending' | 'under_review' | 'completed' | 'rejected';
  resultDate?: string;
  reason?: string;
}

/**
 * Revaluation component for exam paper revaluation requests
 */
const Revaluation: React.FC = () => {
  const [selectedExam, setSelectedExam] = useState('');
  const [reason, setReason] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const examResults: ExamResult[] = [
    {
      id: '1',
      courseCode: 'CS201',
      courseName: 'Data Structures & Algorithms',
      examType: 'endterm',
      semester: '5th Semester',
      marksObtained: 68,
      maxMarks: 100,
      percentage: 68,
      grade: 'B',
      examDate: '2024-12-15',
      resultDate: '2025-01-05',
      canApplyRevaluation: true
    },
    {
      id: '2',
      courseCode: 'CS202',
      courseName: 'Database Management Systems',
      examType: 'endterm',
      semester: '5th Semester',
      marksObtained: 72,
      maxMarks: 100,
      percentage: 72,
      grade: 'B+',
      examDate: '2024-12-18',
      resultDate: '2025-01-05',
      canApplyRevaluation: true
    },
    {
      id: '3',
      courseCode: 'CS203',
      courseName: 'Operating Systems',
      examType: 'midterm',
      semester: '6th Semester',
      marksObtained: 45,
      maxMarks: 75,
      percentage: 60,
      grade: 'C',
      examDate: '2025-01-20',
      resultDate: '2025-01-28',
      canApplyRevaluation: true
    },
    {
      id: '4',
      courseCode: 'CS204',
      courseName: 'Computer Networks',
      examType: 'endterm',
      semester: '5th Semester',
      marksObtained: 78,
      maxMarks: 100,
      percentage: 78,
      grade: 'B+',
      examDate: '2024-12-20',
      resultDate: '2025-01-05',
      canApplyRevaluation: false // Past deadline
    }
  ];

  const revaluationRequests: RevaluationRequest[] = [
    {
      id: '1',
      courseCode: 'CS301',
      courseName: 'Artificial Intelligence',
      examType: 'endterm',
      semester: '5th Semester',
      originalMarks: 65,
      newMarks: 73,
      revaluationFee: 500,
      requestDate: '2024-12-10',
      status: 'completed',
      resultDate: '2024-12-25',
      reason: 'Expected higher marks based on preparation'
    },
    {
      id: '2',
      courseCode: 'CS302',
      courseName: 'Compiler Design',
      examType: 'endterm',
      semester: '5th Semester',
      originalMarks: 58,
      revaluationFee: 500,
      requestDate: '2025-01-08',
      status: 'under_review',
      reason: 'Discrepancy in theory section evaluation'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'under_review': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'under_review': return <RefreshCw className="h-4 w-4" />;
      case 'pending': return <Clock className="h-4 w-4" />;
      case 'rejected': return <AlertTriangle className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getGradeColor = (grade: string) => {
    if (grade.startsWith('A')) return 'text-green-600';
    if (grade.startsWith('B')) return 'text-blue-600';
    if (grade.startsWith('C')) return 'text-yellow-600';
    return 'text-red-600';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));

    setShowSuccess(true);
    setSelectedExam('');
    setReason('');
    setAgreeTerms(false);
    setIsSubmitting(false);

    // Hide success message after 5 seconds
    setTimeout(() => setShowSuccess(false), 5000);
  };

  const selectedExamData = examResults.find(exam => exam.id === selectedExam);
  const revaluationFee = 500; // Standard fee

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Revaluation</h1>
          <p className="text-gray-600">Request revaluation of examination papers</p>
        </div>
      </div>

      {showSuccess && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Your revaluation request has been submitted successfully. Payment details will be sent to your email.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Available for Revaluation */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="mr-2 h-5 w-5" />
              Available for Revaluation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {examResults.filter(exam => exam.canApplyRevaluation).map((exam) => (
                <div
                  key={exam.id}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedExam === exam.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedExam(exam.id)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{exam.courseName}</h4>
                    <Badge className={`${getGradeColor(exam.grade)} bg-gray-100`}>
                      {exam.grade}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-600 space-y-1">
                    <p>{exam.courseCode} - {exam.semester}</p>
                    <p>Marks: {exam.marksObtained}/{exam.maxMarks} ({exam.percentage}%)</p>
                    <p>Exam Date: {new Date(exam.examDate).toLocaleDateString()}</p>
                    <p className="capitalize">{exam.examType} Examination</p>
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-xs text-green-600">✓ Eligible for revaluation</span>
                    <span className="text-xs text-gray-500">
                      Deadline: {new Date(new Date(exam.resultDate).getTime() + 15 * 24 * 60 * 60 * 1000).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))}

              {examResults.filter(exam => !exam.canApplyRevaluation).length > 0 && (
                <div className="border-t pt-4">
                  <h5 className="text-sm font-medium text-gray-700 mb-2">Not Eligible</h5>
                  {examResults.filter(exam => !exam.canApplyRevaluation).map((exam) => (
                    <div key={exam.id} className="p-3 border rounded-lg bg-gray-50 opacity-60">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-medium text-gray-700">{exam.courseName}</h4>
                        <Badge variant="outline">{exam.grade}</Badge>
                      </div>
                      <p className="text-sm text-gray-600">{exam.courseCode} - {exam.semester}</p>
                      <p className="text-xs text-red-600 mt-1">Deadline expired</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Revaluation Request Form */}
        <Card>
          <CardHeader>
            <CardTitle>Request Revaluation</CardTitle>
          </CardHeader>
          <CardContent>
            {!selectedExamData ? (
              <div className="text-center py-12">
                <RefreshCw className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No exam selected</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Choose an exam from the left panel to request revaluation
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-medium text-blue-900 mb-2">Selected Examination</h4>
                  <div className="text-sm text-blue-800 space-y-1">
                    <p><strong>Course:</strong> {selectedExamData.courseName}</p>
                    <p><strong>Code:</strong> {selectedExamData.courseCode}</p>
                    <p><strong>Current Marks:</strong> {selectedExamData.marksObtained}/{selectedExamData.maxMarks}</p>
                    <p><strong>Current Grade:</strong> {selectedExamData.grade}</p>
                    <p><strong>Exam Type:</strong> {selectedExamData.examType}</p>
                  </div>
                </div>

                <div>
                  <Label htmlFor="reason">Reason for Revaluation</Label>
                  <Textarea
                    id="reason"
                    placeholder="Explain why you believe your paper deserves revaluation..."
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    rows={4}
                    required
                  />
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-center mb-2">
                    <DollarSign className="h-4 w-4 text-yellow-600 mr-2" />
                    <span className="font-medium text-yellow-800">Revaluation Fee</span>
                  </div>
                  <p className="text-sm text-yellow-700">
                    A non-refundable fee of ₹{revaluationFee} per paper is applicable.
                    Payment link will be sent after request submission.
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="terms"
                    checked={agreeTerms}
                    onCheckedChange={setAgreeTerms}
                    required
                  />
                  <Label htmlFor="terms" className="text-sm">
                    I agree to the terms and conditions of revaluation process
                  </Label>
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={isSubmitting || !reason || !agreeTerms}
                >
                  {isSubmitting ? 'Submitting Request...' : `Submit Request (₹${revaluationFee})`}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Previous Requests */}
      <Card>
        <CardHeader>
          <CardTitle>Previous Revaluation Requests</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {revaluationRequests.length === 0 ? (
              <div className="text-center py-8">
                <RefreshCw className="mx-auto h-8 w-8 text-gray-400" />
                <p className="text-sm text-gray-500 mt-2">No previous revaluation requests</p>
              </div>
            ) : (
              revaluationRequests.map((request) => (
                <div key={request.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h4 className="font-medium text-gray-900">{request.courseName}</h4>
                      <p className="text-sm text-gray-600">{request.courseCode} - {request.semester}</p>
                    </div>
                    <Badge className={getStatusColor(request.status)} variant="outline">
                      <div className="flex items-center space-x-1">
                        {getStatusIcon(request.status)}
                        <span className="capitalize">{request.status.replace('_', ' ')}</span>
                      </div>
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                    <div>
                      <span className="text-gray-600">Original Marks:</span>
                      <p className="font-medium">{request.originalMarks}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">New Marks:</span>
                      <p className="font-medium">{request.newMarks || 'Pending'}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Fee Paid:</span>
                      <p className="font-medium">₹{request.revaluationFee}</p>
                    </div>
                    <div>
                      <span className="text-gray-600">Requested:</span>
                      <p className="font-medium">{new Date(request.requestDate).toLocaleDateString()}</p>
                    </div>
                  </div>

                  {request.reason && (
                    <div className="mb-3">
                      <span className="text-sm text-gray-600">Reason:</span>
                      <p className="text-sm text-gray-700 mt-1">{request.reason}</p>
                    </div>
                  )}

                  {request.status === 'completed' && request.newMarks && (
                    <div className={`p-3 rounded-lg ${request.newMarks > request.originalMarks ? 'bg-green-50 border border-green-200' : 'bg-gray-50 border border-gray-200'}`}>
                      <p className="text-sm font-medium">
                        {request.newMarks > request.originalMarks ? (
                          <span className="text-green-700">
                            ✓ Marks increased from {request.originalMarks} to {request.newMarks} 
                            (+{request.newMarks - request.originalMarks} marks)
                          </span>
                        ) : request.newMarks === request.originalMarks ? (
                          <span className="text-gray-700">
                            = No change in marks ({request.originalMarks})
                          </span>
                        ) : (
                          <span className="text-red-700">
                            ↓ Marks decreased from {request.originalMarks} to {request.newMarks} 
                            ({request.newMarks - request.originalMarks} marks)
                          </span>
                        )}
                      </p>
                    </div>
                  )}

                  <div className="mt-3 flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Eye className="mr-2 h-4 w-4" />
                      View Details
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle>Revaluation Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Important Points</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Revaluation request must be made within 15 days of result declaration</li>
                <li>• Non-refundable fee of ₹500 per paper</li>
                <li>• Only answer scripts are revaluated, not practicals/viva</li>
                <li>• Marks can increase, decrease, or remain same</li>
                <li>• Results will be declared within 15 working days</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Process Timeline</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Day 0: Submit request and pay fee</li>
                <li>• Day 1-3: Request verification and processing</li>
                <li>• Day 4-10: Answer script revaluation</li>
                <li>• Day 11-15: Result preparation and declaration</li>
                <li>• Notification sent via email and SMS</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Revaluation;
