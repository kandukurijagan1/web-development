/**
 * Main home page redirecting to dashboard
 */
import React from 'react';
import { Navigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';

/**
 * Home page component that redirects based on authentication status
 */
const Home: React.FC = () => {
  const { isAuthenticated } = useAuth();

  // Redirect to dashboard if authenticated, otherwise to login
  return <Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />;
};

export default Home;
